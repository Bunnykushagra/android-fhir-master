---
name:  Research
about: Research tasks
title: ''
labels: 'research'
assignees: ''

---

**Describe the issue to be researched**
Include any background information and available resources.

**Describe the goal of the research**
What's the desired outcome of this task? What artifacts should be produced?

**Describe the methodology**
Where can more information be found? Who should the assignee approach to ask questions? How can a decision be made?

**Would you like to work on the issue?**
