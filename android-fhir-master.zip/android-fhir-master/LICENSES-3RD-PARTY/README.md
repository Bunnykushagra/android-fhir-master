# 3rd-party LICENSE files

Android FHIR SDK uses 3rd-party libraries whose licenses mandate that we
redistribute a copy of the license with our library. These licenses are
contained in this folder.

Our [LicenseeConfig.kt](../buildSrc/src/main/kotlin/LicenseeConfig.kt) file
describes the licenses used by our 3rd-party dependencies in greater detail.
